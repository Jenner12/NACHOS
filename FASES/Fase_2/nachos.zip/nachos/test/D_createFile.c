#include "syscall.h"
#include "stdio.h"
#include "stdlib.h"


int main(int argc, char** argv){
  creat("miArchivo.txt");
  return 0;
}
